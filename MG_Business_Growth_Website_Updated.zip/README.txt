MG·BGC WEBSITE — QUICK START

Language: English
Contact details included:
- Phone / WhatsApp: +20 115 164 9060
- Email: AHMEDBADRYMG@ICLOUD.COM
- Instagram: @mg__business_g

Files:
- index.html: complete responsive one-page website.

Preview:
1. Extract the ZIP.
2. Open index.html in any browser.

Free publishing with GitHub Pages:
1. Create a free GitHub account.
2. Create a public repository named yourusername.github.io.
3. Upload index.html to the repository root.
4. In repository Settings → Pages, enable deployment from the main branch.
5. Your website will be available at https://yourusername.github.io after deployment.

Before publishing:
- Confirm that every company/client name shown in “Our network” is approved for public use and that the relationship wording is accurate.
- Add legal company details and any required privacy/legal notices.
- The contact links open WhatsApp, email, and Instagram.
